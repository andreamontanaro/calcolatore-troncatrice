export interface CalculationFormData {
    name?: string;
    growth: number;
    totalPieces: number;
}